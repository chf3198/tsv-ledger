This is a guide on how to view transactional data of the subscriptions. 

Some data fields will have the data value "N/A". 
This means that there was no data present for that field. 

Billing and Refunds Data.csv
- This csv gives billing details of subscriptions that you own.
- Use the SubscriptionId field to connect data between the Subscriptions.csv in the Digital.Subscriptions.1.zip and this csv.