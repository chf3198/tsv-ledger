This is a guide for how to view your subscription data included in this .zip file.

Some data fields will have the data value "N/A." This means that there was no data present for that field.

It is recommended to read the CSV files in the below order.

Beneficiaries.csv
- This file has details about the beneficiaries of your subscriptions. It helps show if you are the owner or grantee of a subscription. If you are not the owner of a subscription, we will not show you the subscription owner's data to protect the subscription owner's privacy.


Subscriptions.csv
- This file has an overview of the subscriptions that you own.


Subscription Status History.csv
- This file has the status history of your subscriptions.
- Use the SubscriptionId field to connect data between Subscriptions.csv and this file.


Subscription Problems.csv
- This file has the problem history of your subscriptions.
- Use the SubscriptionId field to connect data between Subscriptions.csv and this file.


Billing Schedules.csv
- This file has information about billing periods (frequency of charges) of your subscriptions and benefits related to those subscriptions.
- Use the SubscriptionId and SubscriptionPlanId fields together to connect data between Subscriptions.csv and this file.


Billing Schedule Items.csv
- This file has an itemized view of the charges that occurred for your billing schedules.
- Use the BillingScheduleId field to connect data between Billing Schedules.csv and this file.


Subscription Periods.csv
- This file has information regarding the contract periods (subscription benefit length) and billing periods (frequency of charges) of your subscriptions.
- Use the SubscriptionId and BillingScheduleItemId field together to connect data between Billing Schedule Items.csv and this file.


Payment Plans.csv
- This file has payment plans (schedule of payments) associated with your subscriptions and any general information about those plans.
- Use the SubscriptionId field to connect data between Subscriptions.csv and this file.


Payment Plan Items.csv
- This file has payment details associated with your payment plans.
- Use the PaymentPlanId field to connect data between Payment Plans.csv and this file.
